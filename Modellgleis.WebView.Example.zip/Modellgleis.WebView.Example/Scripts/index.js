﻿
import { Loader } from '/Scripts/loader.js';

(function () {
    const loader = new Loader()
    loader.load();
})();