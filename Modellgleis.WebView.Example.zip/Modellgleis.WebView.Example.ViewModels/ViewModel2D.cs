﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modellgleis.WebView.Example.ViewModels
{
    public class ViewModel2D : IView
    {
    }
}
