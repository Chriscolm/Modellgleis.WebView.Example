namespace Modellgleis.WebView.Example.ViewModels
{
    public interface IView
    {
    }
}
